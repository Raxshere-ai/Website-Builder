// ============================================================
// RAXS STORE — script.js
// FIX: dynamic BASE_URL, robust QR image rendering, countdown
// ============================================================

// ⚡ Vercel Serverless — endpoint ada di /api/
const BASE_URL = window.location.origin + '/api/';

// State
let selectedProduct  = null;
let selectedPrice    = null;
let selectedLevel    = null;
let currentTrxId     = null;
let statusInterval   = null;
let timerInterval    = null;
let expiryTimestamp  = null;

// ============================================================
// HELPERS
// ============================================================
function formatRupiah(n) {
  return 'Rp ' + parseInt(n).toLocaleString('id-ID');
}

function showLoading(show) {
  document.getElementById('loadingOverlay').style.display = show ? 'flex' : 'none';
}

function stopAll() {
  if (statusInterval) { clearInterval(statusInterval); statusInterval = null; }
  if (timerInterval)  { clearInterval(timerInterval);  timerInterval  = null; }
}

// ============================================================
// PRODUCT OPTION SELECTION
// ============================================================
document.querySelectorAll('.option').forEach(opt => {
  opt.addEventListener('click', function () {
    const container = this.closest('.price-options');
    container.querySelectorAll('.option').forEach(o => o.classList.remove('selected'));
    this.classList.add('selected');

    const card = this.closest('.product-card');
    card.dataset.selectedPrice   = this.dataset.price;
    card.dataset.selectedLevel   = this.dataset.level;
  });
});

// ============================================================
// PILIH & BAYAR BUTTON
// ============================================================
document.querySelectorAll('.btn-select').forEach(btn => {
  btn.addEventListener('click', function () {
    const card    = this.closest('.product-card');
    const price   = card.dataset.selectedPrice;
    const level   = card.dataset.selectedLevel;
    const product = this.dataset.product || card.querySelector('.card-title').innerText.trim();

    if (!price || !level) {
      showToast('Pilih level terlebih dahulu!', 'warn');
      return;
    }

    selectedProduct = product;
    selectedPrice   = parseInt(price);
    selectedLevel   = level;

    // Render order summary
    document.getElementById('orderSummary').innerHTML = `
      <div class="order-row">
        <span class="label">Produk</span>
        <span class="value">${selectedProduct}</span>
      </div>
      <div class="order-row">
        <span class="label">Level</span>
        <span class="value">${selectedLevel}</span>
      </div>
      <div class="order-row total">
        <span class="label">Total Bayar</span>
        <span class="value">${formatRupiah(selectedPrice)}</span>
      </div>
    `;

    // Reset form & show payment section
    document.getElementById('customerName').value  = '';
    document.getElementById('customerPhone').value = '';
    document.getElementById('customerEmail').value = '';
    document.getElementById('formCard').style.display  = 'block';
    document.getElementById('qrisCard').style.display  = 'none';

    const section = document.getElementById('paymentSection');
    section.style.display = 'block';
    setTimeout(() => section.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
  });
});

// ============================================================
// CANCEL / BACK
// ============================================================
document.getElementById('cancelButton').addEventListener('click', () => {
  stopAll();
  document.getElementById('paymentSection').style.display = 'none';
  currentTrxId = null;
});

document.getElementById('newOrderBtn').addEventListener('click', () => {
  stopAll();
  document.getElementById('paymentSection').style.display = 'none';
  currentTrxId = null;
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ============================================================
// GENERATE QRIS
// ============================================================
document.getElementById('payButton').addEventListener('click', async () => {
  const name  = document.getElementById('customerName').value.trim();
  const phone = document.getElementById('customerPhone').value.trim();
  const email = document.getElementById('customerEmail').value.trim();

  if (!name)  { showToast('Nama wajib diisi!', 'warn'); return; }
  if (!phone) { showToast('No. WhatsApp wajib diisi!', 'warn'); return; }
  if (phone.length < 9) { showToast('No. WhatsApp tidak valid!', 'warn'); return; }

  stopAll();
  showLoading(true);
  document.getElementById('payButton').disabled = true;

  try {
    const res = await fetch(BASE_URL + 'generate_qris', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount:         selectedPrice,
        customer_name:  name,
        customer_phone: phone,
        customer_email: email,
        product:        selectedProduct,
        level:          selectedLevel
      })
    });

    // Cek content-type sebelum parse
    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json') && !contentType.includes('text/')) {
      throw new Error('Server mengembalikan respons tidak valid. Pastikan PHP aktif di server.');
    }

    const text = await res.text();
    let data;
    try {
      // Bersihkan BOM / whitespace di awal yang kadang muncul dari PHP
      const cleaned = text.trim().replace(/^\uFEFF/, '');
      data = JSON.parse(cleaned);
    } catch {
      // Tampilkan pesan yang lebih informatif beserta raw response
      const preview = text.substring(0, 300).replace(/</g, '&lt;');
      const url     = BASE_URL + 'generate_qris.php';

      // Cek kemungkinan penyebab
      let hint = '';
      if (text.includes('404') || res.status === 404) {
        hint = '⚠️ File backend/generate_qris.php tidak ditemukan.\nPastikan folder backend/ sudah diupload dan path URL benar.';
      } else if (text.includes('<?php') || text.includes('<?PHP')) {
        hint = '⚠️ Server tidak menjalankan PHP (file .php ditampilkan sebagai teks).\nAktifkan PHP di hosting Anda.';
      } else if (text.includes('500') || res.status === 500) {
        hint = '⚠️ PHP error 500. Cek error_log hosting Anda atau aktifkan display_errors sementara.';
      } else if (text.includes('<html') || text.includes('<!DOCTYPE')) {
        hint = '⚠️ Server mengembalikan halaman HTML (bukan PHP). Kemungkinan URL salah atau file tidak ada.';
      } else if (res.status === 0 || text === '') {
        hint = '⚠️ Tidak bisa terhubung ke server. Pastikan diakses lewat hosting (bukan file://).';
      } else {
        hint = '⚠️ Respons tidak dikenali. Lihat detail di bawah.';
      }

      const msg = `${hint}\n\nURL: ${url}\nHTTP Status: ${res.status}\nResponse (300 char pertama):\n${text.substring(0, 300)}`;
      showErrorModal(msg);
      throw new Error('Respons bukan JSON — lihat detail error di layar.');
    }

    if (!data.success) {
      // Tampilkan error lengkap untuk debugging
      const debugInfo = data.api_response
        ? '\n\nAPI Response: ' + JSON.stringify(data.api_response, null, 2)
        : '';
      throw new Error((data.message || 'Gagal generate QRIS') + debugInfo);
    }

    currentTrxId    = data.transaction_id;
    expiryTimestamp = data.expiry;

    showQRIS(data.qr_image, name, phone);

  } catch (err) {
    showToast('Error: ' + err.message, 'error');
    console.error('[RAXS] QRIS Error:', err);
  } finally {
    showLoading(false);
    document.getElementById('payButton').disabled = false;
  }
});

// ============================================================
// RENDER QRIS
// ============================================================
function showQRIS(qrImage, name, phone) {
  document.getElementById('formCard').style.display = 'none';
  const qrisCard = document.getElementById('qrisCard');
  qrisCard.style.display = 'block';

  // Render QR image — support URL atau base64
  const wrap = document.getElementById('qrisImageWrap');
  wrap.innerHTML = '';

  if (!qrImage) {
    wrap.innerHTML = '<p style="color:#ef4444;font-size:.85rem;padding:10px">QR tidak tersedia.<br>Cek koneksi API.</p>';
  } else if (qrImage.startsWith('http') || qrImage.startsWith('//')) {
    // URL langsung
    const img = document.createElement('img');
    img.src = qrImage;
    img.alt = 'QRIS Payment';
    img.onerror = () => {
      wrap.innerHTML = `<div class="qris-string">QR String: ${qrImage}</div>`;
    };
    wrap.appendChild(img);
  } else if (qrImage.startsWith('data:image') || isBase64Image(qrImage)) {
    // Base64 image
    const img = document.createElement('img');
    img.src = qrImage.startsWith('data:') ? qrImage : 'data:image/png;base64,' + qrImage;
    img.alt = 'QRIS Payment';
    wrap.appendChild(img);
  } else if (qrImage.length > 20) {
    // Kemungkinan QR string (untuk ditampilkan atau di-render via library)
    // Coba tampilkan sebagai text biasa dulu
    const div = document.createElement('div');
    div.className = 'qris-string';
    div.textContent = 'QR Code String:\n' + qrImage;
    wrap.appendChild(div);
  } else {
    wrap.innerHTML = '<p style="color:#ef4444;font-size:.85rem">Format QR tidak dikenali.</p>';
  }

  // Info order
  document.getElementById('qrisOrderInfo').innerHTML = `
    <div class="qris-info-row"><span>Produk</span><strong>${selectedProduct} — ${selectedLevel}</strong></div>
    <div class="qris-info-row"><span>Total</span><strong>${formatRupiah(selectedPrice)}</strong></div>
    <div class="qris-info-row"><span>Nama</span><strong>${name}</strong></div>
    <div class="qris-info-row"><span>WhatsApp</span><strong>${phone}</strong></div>
  `;

  // Status
  setStatus('pending', 'Menunggu pembayaran...');

  // Countdown timer
  startTimer();

  // Auto-check status setiap 5 detik
  statusInterval = setInterval(checkStatus, 5000);

  qrisCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function isBase64Image(str) {
  // base64 biasanya panjang dan hanya karakter alphanumeric + /+=
  return /^[A-Za-z0-9+/=]{40,}$/.test(str.replace(/\s/g, ''));
}

// ============================================================
// COUNTDOWN TIMER
// ============================================================
function startTimer() {
  const display = document.getElementById('timerDisplay');
  if (timerInterval) clearInterval(timerInterval);

  timerInterval = setInterval(() => {
    const remaining = expiryTimestamp - Math.floor(Date.now() / 1000);
    if (remaining <= 0) {
      clearInterval(timerInterval);
      display.textContent = '00:00';
      display.classList.add('urgent');
      setStatus('expired', 'QRIS kadaluwarsa. Silakan pesan ulang.');
      stopAll();
      document.getElementById('newOrderBtn').style.display = 'flex';
      return;
    }
    const m = Math.floor(remaining / 60).toString().padStart(2, '0');
    const s = (remaining % 60).toString().padStart(2, '0');
    display.textContent = `${m}:${s}`;
    if (remaining <= 60) display.classList.add('urgent');
  }, 1000);
}

// ============================================================
// CHECK PAYMENT STATUS
// ============================================================
async function checkStatus() {
  if (!currentTrxId) return;
  try {
    const res  = await fetch(BASE_URL + 'check_payment?trx_id=' + currentTrxId);
    const data = await res.json();

    if (data.status === 'paid') {
      stopAll();
      setStatus('paid', '✅ Pembayaran diterima!');
      document.getElementById('newOrderBtn').style.display = 'flex';

      // Show success modal
      document.getElementById('successDetail').innerHTML =
        `Produk: <strong>${selectedProduct}</strong><br>` +
        `Level: <strong>${selectedLevel}</strong><br><br>` +
        `Cek WhatsApp/Email Anda untuk panduan aktivasi.`;
      document.getElementById('successModal').style.display = 'flex';

    } else if (data.status === 'expired') {
      stopAll();
      setStatus('expired', 'QRIS kadaluwarsa. Silakan pesan ulang.');
      document.getElementById('newOrderBtn').style.display = 'flex';
    }
  } catch (e) {
    console.warn('[RAXS] Status check failed:', e);
  }
}

// ============================================================
// STATUS UI
// ============================================================
function setStatus(type, message) {
  const dot  = document.getElementById('statusDot');
  const text = document.getElementById('paymentStatusText');
  dot.className  = 'status-dot ' + type;
  text.textContent = message;
}

// ============================================================
// SUCCESS MODAL CLOSE
// ============================================================
document.getElementById('successClose').addEventListener('click', () => {
  document.getElementById('successModal').style.display = 'none';
  stopAll();
  document.getElementById('paymentSection').style.display = 'none';
  currentTrxId = null;
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ============================================================
// ERROR MODAL (detail lengkap untuk debugging)
// ============================================================
function showErrorModal(msg) {
  let modal = document.getElementById('errorDebugModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'errorDebugModal';
    modal.style.cssText = `
      position:fixed; inset:0; z-index:9998;
      background:rgba(6,6,10,0.92); backdrop-filter:blur(6px);
      display:flex; align-items:center; justify-content:center; padding:20px;
    `;
    modal.innerHTML = `
      <div style="
        background:#12121c; border:1px solid rgba(239,68,68,0.4);
        border-radius:20px; padding:28px; max-width:500px; width:100%;
        max-height:80vh; overflow-y:auto;
      ">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
          <span style="font-size:1.5rem">❌</span>
          <h3 style="font-family:'Syne',sans-serif;font-size:1.1rem;color:#f1f0ff;">
            Error — Tidak Bisa Generate QRIS
          </h3>
        </div>
        <pre id="errorDebugText" style="
          white-space:pre-wrap; word-break:break-word;
          font-size:0.75rem; color:#9ca3af; line-height:1.7;
          background:#06060a; border-radius:10px; padding:14px;
          border:1px solid rgba(255,255,255,0.06); margin-bottom:18px;
        "></pre>
        <p style="font-size:0.78rem; color:#6b7280; margin-bottom:16px;">
          📁 Cek juga: <code style="color:#a78bfa">hosting/raxsstoree/backend/cek.php</code> di browser untuk diagnosis otomatis.
        </p>
        <button onclick="document.getElementById('errorDebugModal').style.display='none'" style="
          width:100%; padding:11px; background:#6366f1; border:none;
          border-radius:100px; color:#fff; font-weight:600; cursor:pointer;
          font-family:'DM Sans',sans-serif;
        ">Tutup</button>
      </div>
    `;
    document.body.appendChild(modal);
  }
  document.getElementById('errorDebugText').textContent = msg;
  modal.style.display = 'flex';
}

// ============================================================
// TOAST NOTIFICATION
// ============================================================
function showToast(msg, type = 'info') {
  let toast = document.getElementById('raxsToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'raxsToast';
    toast.style.cssText = `
      position:fixed; bottom:28px; left:50%; transform:translateX(-50%) translateY(20px);
      background:#1a1a28; border:1px solid rgba(255,255,255,0.1);
      color:#f1f0ff; padding:12px 22px; border-radius:100px;
      font-family:'DM Sans',sans-serif; font-size:0.875rem; font-weight:500;
      z-index:9999; transition:all 0.3s ease; opacity:0;
      box-shadow:0 8px 32px rgba(0,0,0,0.5); white-space:nowrap; max-width:90vw;
    `;
    document.body.appendChild(toast);
  }

  const colors = { warn: '#f59e0b', error: '#ef4444', info: '#6366f1', success: '#22c55e' };
  toast.style.borderColor = (colors[type] || '#6366f1') + '55';
  toast.textContent = msg;

  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
  });

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(10px)';
  }, 3500);
}

// ============================================================
// CLEANUP ON UNLOAD
// ============================================================
window.addEventListener('beforeunload', stopAll);
