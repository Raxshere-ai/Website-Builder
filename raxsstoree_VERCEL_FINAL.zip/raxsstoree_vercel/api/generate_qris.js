// api/generate_qris.js — Vercel Serverless Function
// Pengganti generate_qris.php (Vercel tidak support PHP)

import { readDb, writeDb } from './_db.js';

const API_URL  = 'https://temanqris.com/api/qris';
const API_KEY  = '6347cc348ecb475dbf10a3ba42a2fa65dbe00ad6df044c95b0ecbdd7136ecfd1';

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST')   return res.status(405).json({ success: false, message: 'Method not allowed' });

  const { amount, customer_name, customer_phone, customer_email, product, level } = req.body || {};

  if (!amount || amount < 1000)       return res.status(400).json({ success: false, message: 'Nominal terlalu kecil (min Rp 1.000)' });
  if (!customer_name?.trim())         return res.status(400).json({ success: false, message: 'Nama wajib diisi' });
  if (!customer_phone?.trim())        return res.status(400).json({ success: false, message: 'No. WhatsApp wajib diisi' });

  const transactionId = 'TRX' + Date.now() + Math.floor(Math.random() * 900 + 100);
  const expirySeconds = 300;

  // Webhook URL — Vercel otomatis pakai domain deployment
  const host       = req.headers['x-forwarded-host'] || req.headers.host || '';
  const proto      = req.headers['x-forwarded-proto'] || 'https';
  const webhookUrl = `${proto}://${host}/api/webhook`;

  const payload = {
    api_key:        API_KEY,
    amount:         parseInt(amount),
    transaction_id: transactionId,
    customer_name:  customer_name.trim(),
    customer_phone: customer_phone.trim(),
    customer_email: (customer_email || '').trim(),
    webhook_url:    webhookUrl,
    notes:          `${product || ''} - ${level || ''}`,
    expiry:         expirySeconds,
  };

  let apiRes, apiData;
  try {
    apiRes  = await fetch(API_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body:    JSON.stringify(payload),
    });
    const text = await apiRes.text();
    try { apiData = JSON.parse(text); }
    catch { return res.status(502).json({ success: false, message: 'API TemanQRIS mengembalikan respons tidak valid', raw: text.substring(0, 300) }); }
  } catch (err) {
    return res.status(502).json({ success: false, message: 'Gagal terhubung ke API TemanQRIS: ' + err.message });
  }

  // ── Cari QR image dari semua kemungkinan field ──
  const qrFields = ['qr_image','qr_url','qrcode','qr_code','image','qrImage','qrUrl','qr_string','qrString'];
  let qrImage    = null;

  const searchIn = (obj) => {
    if (!obj || typeof obj !== 'object') return;
    for (const f of qrFields) {
      if (obj[f] && typeof obj[f] === 'string' && obj[f].length > 10) { qrImage = obj[f]; return; }
    }
  };

  searchIn(apiData);
  if (!qrImage) searchIn(apiData?.data);
  if (!qrImage) searchIn(apiData?.result);
  // fallback: jika data adalah string panjang (base64 / URL)
  if (!qrImage && typeof apiData?.data === 'string' && apiData.data.length > 30) qrImage = apiData.data;

  if (!qrImage) {
    return res.status(200).json({
      success:      false,
      message:      'API sukses tapi field QR image tidak ditemukan. Hubungi developer.',
      api_response: apiData,
    });
  }

  // Simpan ke DB
  const db = await readDb();
  db[transactionId] = {
    id:             transactionId,
    amount:         parseInt(amount),
    customer_name:  customer_name.trim(),
    customer_phone: customer_phone.trim(),
    customer_email: (customer_email || '').trim(),
    product:        product || '',
    level:          level   || '',
    status:         'pending',
    expiry:         Math.floor(Date.now() / 1000) + expirySeconds,
    created_at:     Math.floor(Date.now() / 1000),
  };
  await writeDb(db);

  return res.status(200).json({
    success:        true,
    transaction_id: transactionId,
    qr_image:       qrImage,
    expiry:         Math.floor(Date.now() / 1000) + expirySeconds,
  });
}
