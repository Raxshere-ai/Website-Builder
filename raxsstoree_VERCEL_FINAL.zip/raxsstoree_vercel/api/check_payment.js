// api/check_payment.js — Vercel Serverless Function

import { readDb, writeDb } from './_db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const trxId = req.query.trx_id || '';
  if (!trxId) return res.status(400).json({ status: 'error', message: 'Missing trx_id' });

  const db  = await readDb();
  const trx = db[trxId];

  if (!trx) return res.status(404).json({ status: 'not_found' });

  // Auto-expire cek lokal
  if (trx.status === 'pending' && Math.floor(Date.now() / 1000) > trx.expiry) {
    db[trxId].status = 'expired';
    await writeDb(db);
    trx.status = 'expired';
  }

  return res.status(200).json({
    status:  trx.status,
    product: trx.product,
    level:   trx.level,
    amount:  trx.amount,
    expiry:  trx.expiry,
  });
}
