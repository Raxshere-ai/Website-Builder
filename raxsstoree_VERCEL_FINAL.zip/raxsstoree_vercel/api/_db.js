// api/_db.js — Database helper untuk Vercel
// Vercel Serverless tidak punya persistent filesystem.
// Kita pakai /tmp (ephemeral per instance) sebagai cache lokal,
// dan Vercel KV (atau workaround) untuk persistence sebenarnya.
//
// PENTING: Untuk production, aktifkan Vercel KV di dashboard Vercel
// dan ganti implementasi di bawah.

import { promises as fs } from 'fs';
import path from 'path';

// ── Coba pakai Vercel KV jika tersedia ──
let kv = null;
try {
  const kvModule = await import('@vercel/kv').catch(() => null);
  if (kvModule?.kv) { kv = kvModule.kv; }
} catch { /* KV tidak tersedia, pakai /tmp */ }

const TMP_PATH = path.join('/tmp', 'transactions.json');

export async function readDb() {
  // Pakai Vercel KV jika tersedia
  if (kv) {
    try {
      const data = await kv.get('transactions');
      return data || {};
    } catch { /* fallback ke /tmp */ }
  }
  // Fallback: /tmp (hilang setiap cold start, cukup untuk demo/testing)
  try {
    const raw = await fs.readFile(TMP_PATH, 'utf8');
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export async function writeDb(data) {
  // Pakai Vercel KV jika tersedia
  if (kv) {
    try {
      await kv.set('transactions', data);
      return;
    } catch { /* fallback ke /tmp */ }
  }
  // Fallback: /tmp
  try {
    await fs.writeFile(TMP_PATH, JSON.stringify(data), 'utf8');
  } catch { /* ignore write errors */ }
}
