// api/webhook.js — Vercel Serverless Function

import { readDb, writeDb } from './_db.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const input = req.body || {};
  const trxId  = input.transaction_id || input.trx_id || input.order_id || '';
  const status = (input.status || input.payment_status || '').toLowerCase();

  const normalize = (s) => {
    if (['paid','success','settlement','capture','complete','completed'].includes(s)) return 'paid';
    if (['expired','expire','cancel','cancelled','deny','failed'].includes(s))       return 'expired';
    return 'pending';
  };

  if (!trxId) return res.status(400).json({ status: 'error', message: 'Missing transaction_id' });

  const db  = await readDb();
  if (!db[trxId]) return res.status(404).json({ status: 'error', message: 'Transaction not found' });

  db[trxId].status     = normalize(status);
  db[trxId].updated_at = Math.floor(Date.now() / 1000);
  await writeDb(db);

  return res.status(200).json({ status: 'ok', updated: trxId, new_status: normalize(status) });
}
